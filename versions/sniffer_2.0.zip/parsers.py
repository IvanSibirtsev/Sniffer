import argparse
from struct import unpack
import socket as s

TAB_1 = '| \t - '
TAB_2 = '| \t\t - '
TAB_3 = '| \t\t\t - '


def parse_args():
    parser = argparse.ArgumentParser(description="intercepts network traffic")
    parser.add_argument('-f', '--file', dest='filename',
                        help="output pcap filename")
    return parser.parse_args()


def parse_ethernet(data, protocol=''):
    d_mac, s_mac, ether_type = unpack('!6s6sH', data[:14])
    d_mac = get_mac_address(d_mac)
    s_mac = get_mac_address(s_mac)
    ether_type = s.htons(ether_type)
    print(f'| Destination MAC: {d_mac}, Source MAC: {s_mac},' + (
        f' Protocol: {ether_type}.'))
    return data[14:], ether_type


def get_mac_address(a):
    return "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" % (
        a[0], a[1], a[2], a[3], a[4], a[5])


def parse_ipv4(data, protocol=''):
    (version_ihl, tos, total_len, datagram_id, flags_fr_offset, ttl,
     protocol, checksum, s_ip, d_ip) = unpack('!BBHHHBBH4s4s', data[0: 20])

    version = version_ihl >> 4
    ihl = version_ihl & 0xF
    iph_length = ihl * 4

    flags = flags_fr_offset >> 13
    fr_offset = flags_fr_offset & 0xFF

    s_ip = ipv4(s_ip)
    d_ip = ipv4(d_ip)

    if iph_length == 20:
        opt = None
    elif iph_length > 20:
        opt = data[20: iph_length]
    else:
        raise ValueError("Parse IP Header Error")

    print((TAB_1 + f'Version: {version}, Header Length: {iph_length}, ') + (
        f'ToS/DSCP: {tos}, Total Length: {total_len},') + (
        f' Identificator: {datagram_id}.'))
    print((TAB_1 + f'Flags: {flags}, Fragmentation Offset: {fr_offset}, ') + (
        f'TTL: {ttl}, Protocol: {protocol}, Header Checksum: {checksum}.'))
    print(TAB_1 + f'Source IP: {s_ip}, Destination IP: {d_ip}.')

    return data[iph_length:], protocol


def ipv4(address):
    return '.'.join(map(str, address))


def parse_tcp_udp(data, protocol):
    if protocol == 6:
        data = parse_tcp(data)
    elif protocol == 17:
        data = parse_udp(data)
    return data, 'End'


def parse_tcp(data):
    (s_port, d_port, sequence, ackn,
     offset_reserved_flags) = unpack('!HHLLH', data[:14])
    tcp_header_len = data[12] >> 4
    opt = data[20: tcp_header_len]
    window_size, checksum, urgent_pointer = unpack('!HHH', data[14: 20])
    offset = (offset_reserved_flags >> 12) * 4

    urg, ack, psh, rst, syn, fin = parse_tcp_flags(offset_reserved_flags)

    print(TAB_1 + 'TCP Segment:')
    print(TAB_2 + f'Source Port: {s_port}, Destination Port: {d_port}')
    print(TAB_2 + f'Sequence: {sequence}, Acknowledgment: {ackn}, ' + (
        f'Window Size: {window_size}'))
    print(TAB_2 + f'Checksum: {checksum}, Urgent Point: {urgent_pointer}.')
    print(TAB_2 + 'Flags:')
    print(TAB_3 + f'URG: {urg}, ACK: {ack}, PSH: {psh}')
    print(TAB_3 + f'RST: {rst}, SYN: {syn}, FIN: {fin}')

    return data[offset:]


def parse_tcp_flags(offset_reserved_flags):
    urg = (offset_reserved_flags & 32) >> 5
    ack = (offset_reserved_flags & 16) >> 4
    psh = (offset_reserved_flags & 8) >> 3
    rst = (offset_reserved_flags & 4) >> 2
    syn = (offset_reserved_flags & 2) >> 1
    fin = offset_reserved_flags & 1
    return urg, ack, psh, rst, syn, fin


def parse_udp(data):
    s_port, d_port, length, checksum = unpack('!HHHH', data[:8])

    print(TAB_1 + 'UDP Segment:')
    print(TAB_2 + f'Source Port: {s_port}, Destination Port: {d_port}.')
    print(TAB_2 + f'Length: {length}, Checksum: {checksum}.')

    return data[8:]
