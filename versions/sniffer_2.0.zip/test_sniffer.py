import unittest
import pcap
import os

raw_data = b"RT\x00\x125\x02\x08\x00'T\xec\xcd\x08\x00E\x00\x00(>\xdd@\x00@" \
           b"\x06W:\n\x00\x02\x0f\x97e\x01E\x8dp\x01\xbb\x06\x80\xca\xfb\x02" \
           b"\x0cFsP\x10\xf9\x9c\xa4\xd3\x00\x00"


class TestPcap(unittest.TestCase):
    def test_pcap_file_exists_end_close(self):
        self.pcap_maker = pcap.MakePcap('test_pcap.pcap')
        self.pcap_maker.write_packet(raw_data)
        path = os.path.join('pcap', 'test_pcap.pcap')
        self.assertEqual(os.path.exists(path), True)
        os.remove(path)


if __name__ == '__main__':
    unittest.main()
