import socket as s
from parsers import parse_args, parse_ethernet, parse_ipv4, parse_tcp_udp
import hexdump
import io
from contextlib import redirect_stdout
from pcap import MakePcap


def sniffer(args):
    socket = s.socket(s.AF_PACKET, s.SOCK_RAW, s.ntohs(3))
    if args.filename:
        pcap_mod(args, socket)
    else:
        console_mod(socket)


def console_mod(socket):
    while True:
        current_data = socket.recvfrom(655363)[0]
        print(current_data)
        protocol = ''
        print(' ' + '_' * 92)
        for parser in [parse_ethernet, parse_ipv4, parse_tcp_udp]:
            current_data, protocol = parser(current_data, protocol)
        if protocol == 'End' and current_data:
            hex_data = get_hex_dump(current_data)
            print('| Data:')
            print(hex_data, end='')
        print('|' + '_' * 92 + '\n')


def pcap_mod(args, socket):
    data = socket.recvfrom(655363)[0]
    pcap_maker = MakePcap(args.filename)
    pcap_maker.write_packet(data)


def get_hex_dump(data):
    with io.StringIO() as buf, redirect_stdout(buf):
        generator = hexdump.hexdump(data, 'generator')
        for line in generator:
            print('| ' + line)
        output = buf.getvalue()
    return output


def main():
    parsed_args = parse_args()
    sniffer(parsed_args)


if __name__ == '__main__':
    main()
