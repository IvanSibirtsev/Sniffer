import unittest
import sniffer
# Я пока не знаю каким образом тестировать программу.


class TestSniffer(unittest.TestCase):
	def test_parse(self):
        self.assertEqual(1, 1)


if __name__ == '__main__':
    unittest.main()
