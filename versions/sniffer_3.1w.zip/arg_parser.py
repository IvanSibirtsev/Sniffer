import argparse
import sys
import re

LOGIC = {'and', 'or', 'not', '(', ')'}


def parse_args():
    parser = argparse.ArgumentParser(description="intercepts network traffic")
    parser.add_argument('-f', '--file', dest='filename',
                        help="output pcap filename")
    parser.add_argument('-c', '--count', dest='packets_count', default=1,
                        help='count of packets you want to catch')
    parser.add_argument('-p', '--packets_header', dest='headers',
                        default=['any'], action='extend', nargs='+',
                        help='interface you want to sniff. ' +
                             '[eth, ipv4, ipv6, tcp, udp]')
    parser.add_argument('-s', '--special', dest='special', default=['any'],
                        action='extend', nargs='+',
                        help='more detailed information you want to sniff. ' +
                             '[host, src, dst, port]')
    check_count(parser.parse_args())
    check_interfaces(parser.parse_args())
    check_special(parser.parse_args())
    return parser.parse_args()


def check_count(args):
    try:
        count = int(args.packets_count)
    except ValueError:
        print('--count must be a number.')
        sys.exit()
    if count < 0:
        print('--count must be a positive number.')
        sys.exit()


def parse_interfaces(args):
    interfaces = ' '.join(args)
    interfaces = interfaces.replace('any ', '')
    if len(interfaces) <= 1:
        interfaces = 'any'
    if interfaces.count('(') != interfaces.count(')'):
        print('close bracket.')
        sys.exit()
    for replace in [('  ', ' '), ('(', '( '), (')', ' )'), ('  ', ' ')]:
        interfaces = interfaces.replace(replace[0], replace[1])
    return interfaces


def check_interfaces(args):
    interfaces = parse_interfaces(args.headers)
    interfaces = interfaces.split(' ')
    language = {'any', 'eth', 'ipv4', 'ipv6', 'tcp', 'udp'}
    language |= LOGIC
    for interface in interfaces:
        if interface in language:
            pass
        else:
            print(f'Unknown packet header "{interface}". ' +
                  'Try "sudo python3 sniffer.py -h"')
            sys.exit()


def check_special(args):
    specials = parse_interfaces(args.special)
    specials = specials.split(' ')
    language = {'any', 'host', 'src', 'dst', 'port'}
    language |= LOGIC
    ip_regex = re.compile('^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$')
    for spec in specials:
        result = re.match(ip_regex, spec)
        if not (result or spec.isdigit() or spec in language):
            print(f'Unknown "{spec}". Try "sudo python3 sniffer.py -h"')
            sys.exit()


def parse_host(special):
    special = special.split(' ')
    for i in range(len(special)):
        if special[i].find('host') != -1:
            host = special[i]
            index = host.index('=')
            ip = host[index + 1:]
            special[i] = f'( src={ip} or dst={ip} )'
    return special


def parse_special(special):
    special = parse_interfaces(special)
    for name in ['host', 'src', 'dst', 'port']:
        if special.find(name) != -1:
            special = special.replace(name + ' ', name + '=')
    special = parse_host(special)
    special = parse_interfaces(special)
    return special
