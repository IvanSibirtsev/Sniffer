class Args:
    def __init__(self, count='1', headers=['any'], special=['any']):
        self.packets_count = count
        self.headers = headers
        self.special = special
        self.filename = 'filename.pcap'


class TestEthernet:
    def __init__(self):
        self.packet_name = 'eth'

    def to_str(self):
        return self.packet_name


class TestIpv4:
    def __init__(self):
        self.packet_name = 'ipv4'

    def to_str(self):
        return self.packet_name


class TestTCP:
    def __init__(self):
        self.packet_name = 'tcp'
        self.s_port = '80'

    def to_str(self):
        return self.packet_name
