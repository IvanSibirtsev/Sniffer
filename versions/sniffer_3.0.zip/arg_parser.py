import argparse
import sys


def parse_args():
    parser = argparse.ArgumentParser(description="intercepts network traffic")
    parser.add_argument('-f', '--file', dest='filename',
                        help="output pcap filename")
    parser.add_argument('-c', '--count', dest='packets_count', default=1,
                        help='count of packets you want to catch')
    parser.add_argument('-i', '--interface',  dest='interface',
                        default=['all_packets'],  action='extend', nargs='+',
                        help='interface you want to sniff. ' +
                             '[eth0, ipv4, ipv6, tcp, udp]')
    parser.add_argument('-IP=', type=int)
    check_count(parser.parse_args())
    check_interfaces(parser.parse_args())
    return parser.parse_args()


def check_count(args):
    try:
        count = int(args.packets_count)
    except ValueError:
        print('--count must be a number.')
        sys.exit()
    if count < 0:
        print('--count must be a positive number.')
        sys.exit()


def parse_interfaces(args):
    interfaces = ' '.join(args)
    interfaces = interfaces.replace('all_packets ', '')
    if len(interfaces) <= 1:
        interfaces = 'all_packets'
    if interfaces.count('(') != interfaces.count(')'):
        print('close bracket.')
        sys.exit()
    for replace in [('  ', ' '), ('(', '( '), (')', ' )'), ('  ', ' ')]:
        interfaces = interfaces.replace(replace[0], replace[1])
    return interfaces


def check_interfaces(args):
    interfaces = parse_interfaces(args.interface)
    interfaces = interfaces.split(' ')
    language = {'all_packets', 'eth0', 'ipv4', 'ipv6', 'tcp', 'udp',
                'and', 'or', 'not', '(', ')'}
    for interface in interfaces:
        if interface not in language:
            print(f'Unknown interface "{interface}". ' +
                  'Try "sudo python3 sniffer.py -h"')
            sys.exit()
