import socket as s
from parsers import parser_determine
from arg_parser import parse_args, parse_interfaces
from pcap import MakePcap
from packet_filter import Packet


def sniffer(args):
    try:
        socket = s.socket(s.AF_PACKET, s.SOCK_RAW, s.ntohs(3))
        packets_count = int(args.packets_count)
        if args.filename:
            data = {}
            for i in range(packets_count):
                data[i] = socket.recvfrom(655363)[0]
            pcap_mod(args.filename, data, packets_count)
        else:
            if packets_count == 1:
                packets_count = float('inf')
            logic_expression = parse_interfaces(args.interface)
            count = 0
            while count < packets_count:
                current_data = socket.recvfrom(655363)[0]
                console_mod(current_data, logic_expression)
                count += 1
    except PermissionError:
        print('Try sudo')


def console_mod(data, logic_expression):
    protocol = 'Start'
    final_packet = Packet(logic_expression)
    while protocol != 'End' and final_packet.flag:
        packet, data, protocol = parser_determine(data, protocol)
        final_packet.add(packet)


def pcap_mod(filename, raw_data, packets_count):
    pcap_maker = MakePcap(filename)
    pcap_maker.write_packet(raw_data, packets_count)


def main():
    parsed_args = parse_args()
    sniffer(parsed_args)


if __name__ == '__main__':
    main()
