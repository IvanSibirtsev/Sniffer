class Packet:
    def __init__(self, logic_expression):
        self.logic_expression = logic_expression
        if self.logic_expression == 'all_packets':
            self.logic_expression = 'eth0 and (ipv4 or ipv6) and (tcp or udp)'
        self.flag = True

        self.eth0_name = ''
        self.network_name = ''
        self.transport_name = ''
        self.current_packets = []

        self.eth0_packet = None
        self.network_packet = None
        self.transport_packet = None
        self.final_packet = None

    def add(self, packet):  # TODO сделать нормально
        if packet.packet_name in ['eth0']:
            self.eth0_name = packet.packet_name
            self.eth0_packet = packet
            self.current_packets.append(packet.packet_name)

            self.check([self.eth0_packet])

        if packet.packet_name in ['ipv4', 'ipv6']:
            self.network_name = packet.packet_name
            self.network_packet = packet
            self.current_packets.append(packet.packet_name)

            self.check([self.network_packet])
            self.check([self.eth0_packet, self.network_packet])

        if packet.packet_name in ['tcp', 'udp']:
            self.transport_name = packet.packet_name
            self.transport_packet = packet
            self.current_packets.append(packet.packet_name)

            self.check([self.transport_packet])
            self.check([self.eth0_packet, self.transport_packet])
            self.check([self.network_packet, self.transport_packet])
            self.check([self.eth0_packet, self.network_packet,
                        self.transport_packet])

    def check(self, current_packets):
        logic_expression = self.logic_expression

        for name in current_packets:
            if logic_expression.find(name.packet_name) != -1:
                n = name.packet_name
                logic_expression = logic_expression.replace(n, 'True')

        for name in ['eth0', 'ipv4', 'ipv6', 'udp', 'tcp']:
            if logic_expression.find(name) != -1:
                logic_expression = logic_expression.replace(name, 'False')

        if eval(logic_expression):
            self._show_packet(current_packets)
            self.flag = False

    @staticmethod
    def _show_packet(current_packets):
        margin = {'up': '|' + '_' * 92, 'down': '|' + '_' * 92}
        print(margin['up'])
        for packet in current_packets:
            if packet:
                print(packet.to_str())
