import argparse
from struct import unpack
import socket as s
from packets import Ethernet, IPv4, TCP, UDP, BinaryData


def parse_args():
    parser = argparse.ArgumentParser(description="intercepts network traffic")
    parser.add_argument('-f', '--file', dest='filename',
                        help="output pcap filename")
    return parser.parse_args()


def parse_ethernet(data, protocol=''):
    d_mac, s_mac, ether_type = unpack('!6s6sH', data[:14])
    s_mac = get_mac_address(s_mac)
    d_mac = get_mac_address(d_mac)
    ether_type = s.htons(ether_type)
    ethernet_header = Ethernet(s_mac, d_mac, ether_type)
    return ethernet_header, data[14:], ether_type


def get_mac_address(a):
    return "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" % (
        a[0], a[1], a[2], a[3], a[4], a[5])


def parse_ipv4(data):
    (version_ihl, tos, total_len, datagram_id, flags_fr_offset, ttl,
     protocol, checksum, s_ip, d_ip) = unpack('!BBHHHBBH4s4s', data[0: 20])

    version = version_ihl >> 4
    ihl = version_ihl & 0xF
    iph_len = ihl * 4

    flags = flags_fr_offset >> 13
    fr_offset = flags_fr_offset & 0xFF

    s_ip = ipv4(s_ip)
    d_ip = ipv4(d_ip)

    if iph_len == 20:
        opt = None
    elif iph_len > 20:
        opt = data[20: iph_len]

    ipv4_header = IPv4(version, iph_len, tos, total_len, datagram_id, flags,
                       fr_offset, ttl, protocol, checksum, s_ip, d_ip)
    return ipv4_header, data[iph_len:], protocol


def parser_determine(data, protocol):
    try:
        return protocol_to_parser[protocol](data)
    except KeyError:
        return parse_unknown_packet(data, protocol)


def ipv4(address):
    return '.'.join(map(str, address))


def parse_tcp(data):
    (s_port, d_port, sequence, ackn,
     offset_reserved_flags) = unpack('!HHLLH', data[:14])
    tcp_header_len = data[12] >> 4
    opt = data[20: tcp_header_len]
    window_size, checksum, urgent_point = unpack('!HHH', data[14: 20])
    offset = (offset_reserved_flags >> 12) * 4
    flags = parse_tcp_flags(offset_reserved_flags)

    tcp_header = TCP(s_port, d_port, sequence, ackn, window_size, checksum,
                     urgent_point, flags)
    binary_data = BinaryData(data[offset:])
    return tcp_header, binary_data, 'End'


def parse_tcp_flags(offset_reserved_flags):
    urg = (offset_reserved_flags & 32) >> 5
    ack = (offset_reserved_flags & 16) >> 4
    psh = (offset_reserved_flags & 8) >> 3
    rst = (offset_reserved_flags & 4) >> 2
    syn = (offset_reserved_flags & 2) >> 1
    fin = offset_reserved_flags & 1
    return [urg, ack, psh, rst, syn, fin]


def parse_udp(data):
    s_port, d_port, length, checksum = unpack('!HHHH', data[:8])
    udp_header = UDP(s_port, d_port, length, checksum)
    binary_data = BinaryData(data[8:])
    return udp_header, binary_data, 'End'


def parse_unknown_packet(data, protocol):
    data = BinaryData(data)
    return f'\033[31m| Unknown protocol number: {protocol}', data, 'End'


protocol_to_parser = {'Start': parse_ethernet, 8: parse_ipv4, 2054: parse_ipv4,
                      17: parse_udp, 6: parse_tcp}  # 34525: parse_ipv6
