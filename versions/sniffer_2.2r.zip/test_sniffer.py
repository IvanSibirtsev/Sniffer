import unittest
import os
import parsers
import sniffer
import packets
import io
import sys

# region binary data

# TCP
raw_data_1 = b'RT\x00\x125\x02\x08\x00\'T\xec\xcd\x08\x00E\x00\x00(\xfe"@' \
             b'\x00@\x06\xd5\xa2\n\x00\x02\x0f\\z\xfe\x81\xd9\x96\x01\xbbH;}' \
             b'\xa9\x10\x960\xe9P\x10\xf9\x9cg%\x00\x00'
# UDP
raw_data_2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00E\x00' \
             b'\x00J\xeb\xc3@\x00@\x11P\xa9\x7f\x00\x00\x01\x7f\x00\x005\x9a' \
             b'\xfc\x005\x006\xfe}i\xed\x01\x00\x00\x01\x00\x00\x00\x00\x00' \
             b'\x01\x02ru\nwiktionary\x03org\x00\x00\x01\x00\x01\x00\x00)' \
             b'\x04\xb0\x00\x00\x00\x00\x00\x00'

ipv6_data = b'`\x03\x15\xbf\x00(\x06@ \x01\x00\x00S\xaa\x06L\x0cYu{\xd1\xcf' \
            b'\xc3\x13 \x01\x08\xb0\x00\x00\x000\x00\x00\x00\x00\x06f\x01' \
            b'\x02\xba\xf8\x01\xbb\xa4g\xff\x1e\x00\x00\x00\x00\xa0\x02\xfc' \
            b'\x94\xf39\x00\x00\x02\x04\x04\xc4\x04\x02\x08\n+H\x0c\xa7\x00' \
            b'\x00\x00\x00\x01\x03\x03\x07'


# endregion binary data


class TestPcap(unittest.TestCase):
    def test_pcap_file_exists_end_close(self):
        self.pcap_maker = sniffer.pcap_mod('test_pcap.pcap', raw_data_1)
        path = os.path.join('pcap', 'test_pcap.pcap')
        self.assertEqual(os.path.exists(path), True)
        os.remove(path)


class TestParsersTCP(unittest.TestCase):
    def test_ethernet(self):
        self.ethernet, self.data = parsers.parse_ethernet(raw_data_1)[0:2]
        self.right_header = ('08:00:27:54:ec:cd', '52:54:00:12:35:02', 8)
        self.ethernet_header = self.ethernet.get_all_ethernet_information()
        self.assertEqual(self.ethernet_header, self.right_header)
        return self.data

    def test_ipv4(self):
        self.data = self.test_ethernet()
        self.ipv4, self.data = parsers.parse_ipv4(self.data)[0:2]
        self.right_header = (4, 20, 0, 40, 65058, 2, 0, 64, 6, 54690,
                             '10.0.2.15', '92.122.254.129')
        self.ipv4_header = self.ipv4.get_all_ipv4_information()
        self.assertEqual(self.ipv4_header, self.right_header)
        return self.data

    def test_tcp(self):
        self.data = self.test_ipv4()
        self.tcp = parsers.parse_tcp(self.data)[0]
        self.tcp_header = self.tcp.get_all_tcp_information()
        self.right_header = (55702, 443, 1211858345, 278278377, 63900, 26405,
                             0, [0, 1, 0, 0, 0, 0])
        self.assertEqual(self.tcp_header, self.right_header)


class TestParsersToUDP(unittest.TestCase):
    def make_udp_data(self):
        self.data = raw_data_2
        for parser in [parsers.parse_ethernet, parsers.parse_ipv4]:
            self.data = parser(self.data)[1]
        return self.data

    def test_udp(self):
        self.data = self.make_udp_data()
        self.udp = parsers.parse_udp(self.data)[0]
        self.udp_header = self.udp.get_all_udp_information()
        self.right_header = (39676, 53, 54, 65149)
        self.assertEqual(self.udp_header, self.right_header)


class TestSniffer(unittest.TestCase):
    def test_exception(self):
        if os.getuid() != 0:
            old_stdout = sys.stdout
            sys.stdout = buffer = io.StringIO()
            sniffer.sniffer('')
            sys.stdout = old_stdout
            output = buffer.getvalue()
            self.assertEqual(output, 'Try sudo\n')


class TestCUI(unittest.TestCase):
    def test_ethernet(self):
        self.ethernet_inf = packets.Ethernet(1, 1, 0)
        self.right = '| Destination MAC: 1, Source MAC: 1, Protocol: 0.'
        self.assertEqual(str(self.ethernet_inf), self.right)

    def test_ipv4(self):
        self.ipv4_inf = packets.IPv4(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
        self.right = packets.TAB_1
        self.right += 'Version: 1, Header Length: 1, ToS/DSCP: 1,' \
                      ' Total Length: 1, Identificator: 1.\n' + packets.TAB_1
        self.right += 'Flags: 1, Fragmentation Offset: 1, TTL: 1,' \
                      ' Protocol: 1, Header Checksum: 1.\n' + packets.TAB_1
        self.right += 'Source IP: 1, Destination IP: 1.'
        self.assertEqual(str(self.ipv4_inf), self.right)

    def test_tcp(self):
        self.tcp_inf = packets.TCP(1, 1, 1, 1, 1, 1, 1, [1, 1, 1, 1, 1, 1])
        self.right = packets.TAB_1 + 'TCP Segment:\n' + packets.TAB_2
        self.right += 'Source Port: 1, Destination Port: 1\n' + packets.TAB_2
        self.right += 'Sequence: 1, Acknowledgment: 1, Window Size: 1\n'
        self.right += packets.TAB_2 + 'Checksum: 1, Urgent Point: 1.\n'
        self.right += packets.TAB_2 + 'Flags:\n'
        self.right += packets.TAB_3 + 'URG: 1, ACK: 1, PSH: 1\n'
        self.right += packets.TAB_3 + 'RST: 1, SYN: 1, FIN: 1'
        self.assertEqual(str(self.tcp_inf), self.right)

    def test_udp(self):
        self.udp_inf = packets.UDP(1, 1, 1, 1)
        self.right = packets.TAB_1 + 'UDP Segment:\n' + packets.TAB_2
        self.right += 'Source Port: 1, Destination Port: 1.\n' + packets.TAB_2
        self.right += 'Length: 1, Checksum: 1.'
        self.assertEqual(str(self.udp_inf), self.right)


if __name__ == '__main__':
    unittest.main()
