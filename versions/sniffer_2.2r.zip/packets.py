import io
import hexdump
from contextlib import redirect_stdout

TAB_1 = '| \t - '
TAB_2 = '| \t\t - '
TAB_3 = '| \t\t\t - '


class Ethernet:
    def __init__(self, src, destination, ether_type):
        self.s_mac = src
        self.d_mac = destination
        self.ether_type = ether_type

    def get_all_ethernet_information(self):
        return self.s_mac, self.d_mac, self.ether_type

    def __str__(self):
        s = f'| Destination MAC: {self.s_mac}, Source MAC: {self.d_mac}, ' \
            f'Protocol: {self.ether_type}.'
        return s


class IPv4:
    def __init__(self, version, iph_len, tos, total_len, datagram_id, flags,
                 fr_offset, ttl, protocol, checksum, s_ip, d_ip):
        # region init
        self.version = version
        self.iph_len = iph_len
        self.tos = tos
        self.total_len = total_len
        self.datagram_id = datagram_id
        self.flags = flags
        self.fr_offset = fr_offset
        self.ttl = ttl
        self.protocol = protocol
        self.checksum = checksum
        self.s_ip = s_ip
        self.d_ip = d_ip
        # endregion init

    def get_all_ipv4_information(self):
        return (self.version, self.iph_len, self.tos, self.total_len,
                self.datagram_id, self.flags, self.fr_offset, self.ttl,
                self.protocol, self.checksum, self.s_ip, self.d_ip)

    def __str__(self):
        s = TAB_1
        s += f'Version: {self.version}, Header Length: {self.iph_len}, ' \
            f'ToS/DSCP: {self.tos}, Total Length: {self.total_len}, ' \
            f'Identificator: {self.datagram_id}.\n' + TAB_1
        s += f'Flags: {self.flags}, Fragmentation Offset: {self.fr_offset},' \
            f' TTL: {self.ttl}, Protocol: {self.protocol}, ' \
            f'Header Checksum: {self.checksum}.\n' + TAB_1
        s += f'Source IP: {self.s_ip}, Destination IP: {self.d_ip}.'
        return s

# region
"""
class IPv6:
    def __init__(self, version, traffic_class, flow_label, payload_label,
                 protocol, ttl, source, destination):
        self.version = version
        self.traffic_class = traffic_class
        self.flow_label = flow_label
        self.payload_label = payload_label
        self.protocol = protocol
        self.ttl = ttl
        self.source = source
        self.destination = destination

    def get_all_information(self):
        return (self.version, self.traffic_class, self.flow_label,
                self.payload_label, self.protocol, self.ttl, self.source,
                self.destination)

    def __str__(self):
        s = TAB_1
        return s


class APR:
    def __init__(self, hardware_type, proto_type, hw_address_len,
                 proto_address_len, op_code, hw_address_sender,
                 proto_address_sender, hw_address_target,
                 proto_address_target):
        # region init
        self.hw_type = hardware_type
        self.proto_type = proto_type
        self.hw_address_len = hw_address_len
        self.proto_address_len = proto_address_len
        self.op_code = op_code
        self.hw_address_sender = hw_address_sender
        self.proto_address_sender = proto_address_sender
        self.hw_address_target = hw_address_target
        self.proto_address_target = proto_address_target
        # endregion init

    def get_all_information(self):
        return (self.hw_type, self.proto_type, self.hw_address_len,
                self.proto_address_len, self.op_code, self.hw_address_sender,
                self.hw_address_target, self.proto_address_target)
"""
# endregion


class TCP:
    def __init__(self, s_port, d_port, sequence, ackn, window_size, checksum,
                 urgent_point, flags):
        self.s_port = s_port
        self.d_port = d_port
        self.seq = sequence
        self.ackn = ackn
        self.w_size = window_size
        self.checksum = checksum
        self.urgent_point = urgent_point
        self.f = flags

    def get_all_tcp_information(self):
        return (self.s_port, self.d_port, self.seq, self.ackn, self.w_size,
                self.checksum, self.urgent_point, self.f)

    def __str__(self):
        s = TAB_1 + 'TCP Segment:\n' + TAB_2
        s += f'Source Port: {self.s_port}, Destination Port: {self.d_port}\n'
        s += TAB_2
        s += f'Sequence: {self.seq}, Acknowledgment: {self.ackn}, ' \
            f'Window Size: {self.w_size}\n' + TAB_2
        s += f'Checksum: {self.checksum}, Urgent Point: {self.urgent_point}.\n'
        s += TAB_2 + 'Flags:\n'
        s += TAB_3 + f'URG: {self.f[0]}, ACK: {self.f[1]}, PSH: {self.f[2]}\n'
        s += TAB_3 + f'RST: {self.f[3]}, SYN: {self.f[4]}, FIN: {self.f[5]}'
        return s


class UDP:
    def __init__(self, s_port, d_port, length, checksum):
        self.s_port = s_port
        self.d_port = d_port
        self.length = length
        self.checksum = checksum

    def get_all_udp_information(self):
        return self.s_port, self.d_port, self.length, self.checksum

    def __str__(self):
        s = TAB_1 + 'UDP Segment:\n' + TAB_2
        s += f'Source Port: {self.s_port}, Destination Port: {self.d_port}.\n'
        s += TAB_2 + f'Length: {self.length}, Checksum: {self.checksum}.'
        return s


class BinaryData:
    def __init__(self, binary_data):
        self.binary_data = binary_data

    def get_hex_dump(self):
        with io.StringIO() as buf, redirect_stdout(buf):
            generator = hexdump.hexdump(self.binary_data, 'generator')
            for line in generator:
                print('| ' + line)
            output = buf.getvalue()
        return output

    def __str__(self):
        s = self.get_hex_dump()
        return s
