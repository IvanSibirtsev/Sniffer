import socket as s
from parsers import parse_args, parse_ethernet, parse_ipv4_ipv6, parse_tcp_udp
from pcap import MakePcap


def sniffer(args):
    try:
        socket = s.socket(s.AF_PACKET, s.SOCK_RAW, s.ntohs(3))
        if args.filename:
            data = socket.recvfrom(655363)[0]
            pcap_mod(args.filename, data)
        else:
            while True:
                current_data = socket.recvfrom(655363)[0]
                print(console_mod(current_data))
    except PermissionError:
        print('Try sudo')


def console_mod(current_data):
    protocol = ''
    all_information = ' ' + '_' * 92 + '\n'
    for parser in [parse_ethernet, parse_ipv4_ipv6, parse_tcp_udp]:
        packet, current_data, protocol = parser(current_data, protocol)
        all_information += str(packet) + '\n'
    if protocol == 'End' and current_data:
        all_information += '| Data:\n' + str(current_data)
    all_information += '|' + '_' * 92 + '\n'
    return all_information


def pcap_mod(filename, raw_data):
    pcap_maker = MakePcap(filename)
    pcap_maker.write_packet(raw_data)


def main():
    parsed_args = parse_args()
    sniffer(parsed_args)


if __name__ == '__main__':
    main()
