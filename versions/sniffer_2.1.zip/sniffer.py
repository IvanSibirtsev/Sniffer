import socket as s
from parsers import parse_args, parse_ethernet, parse_ipv4, parse_tcp_udp
import hexdump
import io
from contextlib import redirect_stdout
from pcap import MakePcap


def sniffer(args):
    try:
        socket = s.socket(s.AF_PACKET, s.SOCK_RAW, s.ntohs(3))
        if args.filename:
            pcap_mod(args, socket)
        else:
            while True:
                current_data = socket.recvfrom(655363)[0]
                print(console_mod(current_data))
    except PermissionError:
        print('Try sudo')


def console_mod(current_data):
    protocol = ''
    all_information = ' ' + '_' * 92 + '\n'
    for parser in [parse_ethernet, parse_ipv4, parse_tcp_udp]:
        packet, current_data, protocol = parser(current_data, protocol)
        all_information += str(packet) + '\n'
    if protocol == 'End' and current_data:
        hex_data = get_hex_dump(current_data)
        all_information += '| Data:\n' + hex_data
    all_information += '|' + '_' * 92 + '\n'
    return all_information


def pcap_mod(args, socket):
    data = socket.recvfrom(655363)[0]
    pcap_maker = MakePcap(args.filename)
    pcap_maker.write_packet(data)


def get_hex_dump(data):
    with io.StringIO() as buf, redirect_stdout(buf):
        generator = hexdump.hexdump(data, 'generator')
        for line in generator:
            print('| ' + line)
        output = buf.getvalue()
    return output


def main():
    parsed_args = parse_args()
    sniffer(parsed_args)


if __name__ == '__main__':
    main()
